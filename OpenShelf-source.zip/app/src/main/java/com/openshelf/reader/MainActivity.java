package com.openshelf.reader;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.content.Intent;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.view.View;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.XMLConstants;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Native offline storage, EPUB/PDF parsing and Android document picker for the embedded UI. */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final int PICK_BOOKS = 1204;
    private static final String TAG = "OpenShelf";
    private WebView web;
    private File booksRoot;
    private File dbFile;
    private final Object dbLock = new Object();
    private volatile boolean volumeKeysEnabled = false;
    private volatile boolean readerIsOpen = false;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(250,249,255));
        getWindow().setNavigationBarColor(Color.rgb(240,239,246));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(true);
        booksRoot = new File(getFilesDir(),"books"); booksRoot.mkdirs();
        dbFile = new File(getFilesDir(),"books.json");
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(250,249,255));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setWebChromeClient(new WebChromeClient());
        WebSettings w = web.getSettings();
        w.setJavaScriptEnabled(true);
        w.setDomStorageEnabled(true);
        w.setAllowFileAccess(false);
        w.setAllowContentAccess(false);
        w.setSupportZoom(false);
        w.setBuiltInZoomControls(false);
        w.setMediaPlaybackRequiresUserGesture(false);
        w.setDefaultTextEncodingName("UTF-8");
        w.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new Backend(), "OpenShelfNative");
        web.setWebViewClient(new LocalClient());
        setContentView(web);
        web.loadUrl("https://"+HOST+"/assets/index.html");
        if (getIntent()!=null && getIntent().getData()!=null) importIntent(getIntent());
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);setIntent(intent);importIntent(intent);
    }
    private class LocalClient extends WebViewClient {
        @Override public void onPageFinished(WebView view,String url){ super.onPageFinished(view,url); if(url.startsWith("https://"+HOST+"/assets/index.html"))view.evaluateJavascript("window.refreshNativeBooks&&window.refreshNativeBooks()",null); }
        @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            Uri u=req.getUrl();return !(HOST.equals(u.getHost()) && "https".equals(u.getScheme()));
        }
        @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            Uri uri=req.getUrl();
            if(!HOST.equals(uri.getHost()) || !"https".equals(uri.getScheme()))return empty();
            String path=uri.getPath();
            try {
                if(path.startsWith("/assets/")) {
                    String relative=path.substring(8);
                    if(relative.contains("..") || relative.startsWith("/"))return empty();
                    return new WebResourceResponse(mime(relative),"utf-8",getAssets().open(relative));
                }
                if(path.startsWith("/files/")) {
                    File requested = new File(getFilesDir(), path.substring(7));
                    File base = getFilesDir().getCanonicalFile();
                    String target=requested.getCanonicalPath();
                    if(!target.startsWith(base.getPath()+File.separator)||!requested.isFile())return empty();
                    FileInputStream input=new FileInputStream(requested);
                    WebResourceResponse res=new WebResourceResponse(mime(path),mime(path).startsWith("text/")?"utf-8":null,input);
                    res.setResponseHeaders(Collections.singletonMap("Cache-Control","private, max-age=86400"));
                    return res;
                }
            }catch(Exception e){ Log.w(TAG,"Unable to load local file: "+path,e); }
            return empty();
        }
        private WebResourceResponse empty(){return new WebResourceResponse("text/plain","utf-8",new ByteArrayInputStream(new byte[0]));}
    }
    private static String mime(String path){
        String n=path.toLowerCase(Locale.ROOT);
        if(n.endsWith(".html")||n.endsWith(".htm"))return "text/html";
        if(n.endsWith(".xhtml")||n.endsWith(".xml"))return "application/xhtml+xml";
        if(n.endsWith(".css"))return "text/css";
        if(n.endsWith(".js"))return "text/javascript";
        if(n.endsWith(".svg"))return "image/svg+xml";
        if(n.endsWith(".png"))return "image/png";
        if(n.endsWith(".jpg")||n.endsWith(".jpeg"))return "image/jpeg";
        if(n.endsWith(".gif"))return "image/gif";
        if(n.endsWith(".webp"))return "image/webp";
        if(n.endsWith(".mp3"))return "audio/mpeg";
        if(n.endsWith(".m4a")||n.endsWith(".aac"))return "audio/mp4";
        if(n.endsWith(".ogg"))return "audio/ogg";
        if(n.endsWith(".wav"))return "audio/wav";
        if(n.endsWith(".txt"))return "text/plain";
        if(n.endsWith(".pdf"))return "application/pdf";
        return "application/octet-stream";
    }
    private class Backend {
        @JavascriptInterface public String getBooks(){ synchronized(dbLock){return readBooks().toString();} }
        @JavascriptInterface public void pickFiles(){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/epub+zip","application/pdf","application/zip","application/x-cbz","text/plain","text/html","audio/mpeg","audio/mp4","audio/aac","audio/ogg","audio/wav","application/octet-stream","application/vnd.comicbook+zip"});startActivityForResult(i,PICK_BOOKS);});}
        @JavascriptInterface public void deleteBook(String id){ synchronized(dbLock){JSONArray arr=readBooks(),out=new JSONArray();for(int i=0;i<arr.length();i++){JSONObject b=arr.optJSONObject(i);if(b!=null&&!id.equals(b.optString("id")))out.put(b);}writeBooks(out);};deleteRecursive(new File(booksRoot,safeId(id))); }
        @JavascriptInterface public void updateBook(String id,String title,String author,String series){synchronized(dbLock){JSONArray arr=readBooks();for(int i=0;i<arr.length();i++){JSONObject b=arr.optJSONObject(i);if(b!=null&&id.equals(b.optString("id"))){try{b.put("title",title).put("author",author).put("series",series);}catch(JSONException ignored){}break;}}writeBooks(arr);}}
        @JavascriptInterface public String readText(String id){File b=new File(new File(booksRoot,safeId(id)),"source");if(!b.isFile())return "";try(FileInputStream in=new FileInputStream(b)){byte[] bytes=readLimited(in,9_000_000);return new String(bytes,StandardCharsets.UTF_8);}catch(Exception e){return "";}}
        @JavascriptInterface public String renderPdfPage(String id,int page,int width){return renderPdf(id,page,width);}
        @JavascriptInterface public void setVolumeKeys(boolean on){volumeKeysEnabled=on;}
        @JavascriptInterface public void setReading(boolean on){readerIsOpen=on;}
        @JavascriptInterface public void setAppTheme(boolean isDark){runOnUiThread(()->{
            int flags=isDark?0:(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            getWindow().getDecorView().setSystemUiVisibility(flags);
            getWindow().setStatusBarColor(isDark?Color.rgb(23,24,29):Color.rgb(250,249,255));
            getWindow().setNavigationBarColor(isDark?Color.rgb(39,40,50):Color.rgb(240,239,246));
        });}
        @JavascriptInterface public void setBrightness(int percent){runOnUiThread(()->{WindowManager.LayoutParams p=getWindow().getAttributes();p.screenBrightness=percent>=100?-1:Math.max(.05f,percent/100f);getWindow().setAttributes(p);});}
        @JavascriptInterface public void setAutoRotate(boolean enable){runOnUiThread(()->setRequestedOrientation(enable?ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR:ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED));}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request!=PICK_BOOKS||result!=RESULT_OK||data==null)return;ArrayList<Uri> uris=new ArrayList<>();if(data.getClipData()!=null){ClipData clip=data.getClipData();for(int i=0;i<clip.getItemCount();i++)uris.add(clip.getItemAt(i).getUri());}else if(data.getData()!=null)uris.add(data.getData());importUris(uris);}
    private void importIntent(Intent intent){ArrayList<Uri> list=new ArrayList<>();if(intent.getData()!=null)list.add(intent.getData());importUris(list);}
    private void importUris(List<Uri> uris){if(uris.isEmpty())return;new Thread(()->{int completed=0;for(Uri uri:uris){try{importBook(uri);completed++;}catch(Exception e){Log.e(TAG,"Import failed: "+uri,e);}}int n=completed;runOnUiThread(()->{web.evaluateJavascript("window.__onImported&&window.__onImported()",null);if(n==0)web.evaluateJavascript("(window.toast||function(){})('Unable to import selected files')",null);});},"import-books").start();}
    private String fileName(Uri uri){try(Cursor c=getContentResolver().query(uri,null,null,null,null)){if(c!=null&&c.moveToFirst()){int idx=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(idx>=0)return c.getString(idx);}}catch(Exception ignored){}return uri.getLastPathSegment()==null?"Book":uri.getLastPathSegment();}
    private static String safeId(String id){return id==null?"":id.replaceAll("[^A-Za-z0-9_-]","");}
    private void importBook(Uri uri)throws Exception {
        String name=fileName(uri);int dot=name.lastIndexOf('.');String ext=dot>=0?name.substring(dot+1).toLowerCase(Locale.ROOT):"";
        String fmt;
        switch(ext){case "epub":fmt="epub";break;case "pdf":fmt="pdf";break;case "cbz":fmt="cbz";break;case "txt":fmt="txt";break;case "html":case "htm":fmt="html";break;case "mp3":case "m4a":case "aac":case "ogg":case "wav":fmt="audio";break;default:throw new IOException("Unsupported extension: "+ext);}
        String id="bk_"+UUID.randomUUID().toString().replace("-","");File root=new File(booksRoot,id);if(!root.mkdirs())throw new IOException("Cannot create book directory");
        File source=new File(root,fmt.equals("audio") ? ("source."+ext) : "source");
        try {
            long total=0;
            try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new BufferedOutputStream(new FileOutputStream(source))){if(in==null)throw new IOException("Could not open file");byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1){total+=n;if(total>1_500_000_000L)throw new IOException("Book is too large");out.write(buf,0,n);}}
            JSONObject item=new JSONObject();
            item.put("id",id).put("format",fmt).put("title",dot>0?name.substring(0,dot):name).put("author","").put("series","").put("added",System.currentTimeMillis()).put("size",total).put("cover","").put("pageCount",1).put("chapters",new JSONArray()).put("pages",new JSONArray());
            if(fmt.equals("epub"))parseEpub(source,root,item);
            if(fmt.equals("cbz"))parseCbz(source,root,item);
            if(fmt.equals("pdf")){try(ParcelFileDescriptor fd=ParcelFileDescriptor.open(source,ParcelFileDescriptor.MODE_READ_ONLY);PdfRenderer renderer=new PdfRenderer(fd)){item.put("pageCount",renderer.getPageCount());}catch(Exception e){Log.w(TAG,"Can't inspect PDF",e);}String cover=renderPdfBitmap(source,new File(root,"cover.png"),0,300);if(cover!=null)item.put("cover","files/books/"+id+"/cover.png");}
            if(fmt.equals("audio"))item.put("file","files/books/"+id+"/source."+ext);
            synchronized(dbLock){JSONArray arr=readBooks();arr.put(item);writeBooks(arr);}
        }catch(Exception ex){deleteRecursive(root);throw ex;}
    }
    private static JSONArray readJson(File file){try(FileInputStream in=new FileInputStream(file)){return new JSONArray(new String(readLimited(in,15_000_000),StandardCharsets.UTF_8));}catch(Exception ignored){return new JSONArray();}}
    private JSONArray readBooks(){return readJson(dbFile);}
    private void writeBooks(JSONArray books){try{File temp=new File(getFilesDir(),"books.tmp");try(FileOutputStream out=new FileOutputStream(temp)){out.write(books.toString().getBytes(StandardCharsets.UTF_8));out.getFD().sync();}if(!temp.renameTo(dbFile))throw new IOException("Could not save library index");}catch(Exception e){Log.e(TAG,"Saving library failed",e);}}
    private static byte[] readLimited(InputStream in,int max)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[32768];int n,total=0;while((n=in.read(buf))!=-1){total+=n;if(total>max)throw new IOException("Content too large");out.write(buf,0,n);}return out.toByteArray();}
    private static void deleteRecursive(File f){if(!f.exists())return;if(f.isDirectory()){File[] entries=f.listFiles();if(entries!=null)for(File c:entries)deleteRecursive(c);}f.delete();}
    private static void unzip(File zipFile,File destination)throws IOException {
        File canonicalRoot=destination.getCanonicalFile();if(!canonicalRoot.exists()&&!canonicalRoot.mkdirs())throw new IOException("Cannot create extract directory");
        long max=1_400_000_000L,total=0;int count=0;
        try(ZipInputStream zip=new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile)))){
            ZipEntry entry;byte[] buf=new byte[65536];while((entry=zip.getNextEntry())!=null){if(++count>12000)throw new IOException("Too many files in archive");File out=new File(destination,entry.getName());String resolved=out.getCanonicalPath();if(!resolved.startsWith(canonicalRoot.getPath()+File.separator))throw new IOException("Unsafe archive path");if(entry.isDirectory()){out.mkdirs();continue;}File parent=out.getParentFile();if(!parent.exists()&&!parent.mkdirs())throw new IOException("Cannot extract archive");try(OutputStream os=new BufferedOutputStream(new FileOutputStream(out))){int n;while((n=zip.read(buf))!=-1){total+=n;if(total>max)throw new IOException("Extracted files exceed safety limit");os.write(buf,0,n);}}zip.closeEntry();}}
    }
    private static Document xml(File file)throws Exception {
        DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();factory.setNamespaceAware(true);factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,true);factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);factory.setFeature("http://xml.org/sax/features/external-general-entities",false);factory.setFeature("http://xml.org/sax/features/external-parameter-entities",false);factory.setExpandEntityReferences(false);return factory.newDocumentBuilder().parse(file);
    }
    private static NodeList tag(Document d,String local){return d.getElementsByTagNameNS("*",local);}
    private static String text(Document doc,String local){NodeList nodes=tag(doc,local);return nodes.getLength()>0?nodes.item(0).getTextContent().trim():"";}
    private static String attribute(Node node,String attr){if(node==null||node.getAttributes()==null)return "";Node a=node.getAttributes().getNamedItem(attr);return a==null?"":a.getNodeValue();}
    private static String safeRelative(String base,String relative){try{return new File(new File(base).getParentFile(),relative.replace('\\','/')).toPath().normalize().toString().replace('\\','/');}catch(Exception ex){return relative;}}
    private static String bookURL(String id,String path){return "files/books/"+id+"/content/"+Uri.encode(path.replace('\\','/'),"/");}
    private void parseEpub(File source,File root,JSONObject item)throws Exception {
        String id=item.getString("id");File content=new File(root,"content");unzip(source,content);
        Document container=xml(new File(content,"META-INF/container.xml"));
        NodeList roots=tag(container,"rootfile");if(roots.getLength()==0)throw new IOException("No EPUB rootfile");
        String opf=attribute(roots.item(0),"full-path");File opfFile=new File(content,opf);
        Document packageDoc=xml(opfFile);String title=text(packageDoc,"title"),author=text(packageDoc,"creator");
        if(!title.isEmpty())item.put("title",title);if(!author.isEmpty())item.put("author",author);
        HashMap<String,String> itemPaths=new HashMap<>();HashMap<String,String> itemProperties=new HashMap<>();
        NodeList manifest=tag(packageDoc,"item");
        for(int i=0;i<manifest.getLength();i++){Node n=manifest.item(i);String key=attribute(n,"id"),href=attribute(n,"href");itemPaths.put(key,safeRelative(opf,href.split("#")[0]));itemProperties.put(key,attribute(n,"properties"));}
        String coverRef="";NodeList metas=tag(packageDoc,"meta");for(int i=0;i<metas.getLength();i++){Node m=metas.item(i);if("cover".equals(attribute(m,"name")))coverRef=attribute(m,"content");if("calibre:series".equals(attribute(m,"name")))item.put("series",attribute(m,"content"));}
        JSONArray chapters=new JSONArray();NodeList refs=tag(packageDoc,"itemref");
        for(int i=0;i<refs.getLength();i++){String k=attribute(refs.item(i),"idref");String p=itemPaths.get(k);if(p==null||(!p.endsWith(".html")&&!p.endsWith(".xhtml")&&!p.endsWith(".htm")))continue;File chapterFile=new File(content,p);if(!chapterFile.exists())continue;JSONObject ch=new JSONObject();ch.put("url",bookURL(id,p));ch.put("title","Chapter "+(chapters.length()+1));chapters.put(ch);}
        item.put("chapters",chapters).put("pageCount",Math.max(1,chapters.length()));
        String coverPath=itemPaths.get(coverRef);
        if(coverPath==null){for(String k:itemProperties.keySet()){if(itemProperties.get(k).contains("cover-image")){coverPath=itemPaths.get(k);break;}}}
        if(coverPath==null){for(String p:itemPaths.values()){if(p.toLowerCase(Locale.ROOT).matches(".*cover[^/]*\\.(jpg|jpeg|png|webp)$")){coverPath=p;break;}}}
        if(coverPath!=null&&new File(content,coverPath).isFile())item.put("cover",bookURL(id,coverPath));
    }
    private static int naturalCompare(String a,String b){
        a=a.toLowerCase(Locale.ROOT);b=b.toLowerCase(Locale.ROOT);int i=0,j=0;
        while(i<a.length()&&j<b.length()){
            char x=a.charAt(i),y=b.charAt(j);
            if(Character.isDigit(x)&&Character.isDigit(y)){
                int i2=i,j2=j;while(i2<a.length()&&Character.isDigit(a.charAt(i2)))i2++;while(j2<b.length()&&Character.isDigit(b.charAt(j2)))j2++;
                String ax=a.substring(i,i2).replaceFirst("^0+(?!$)","");String by=b.substring(j,j2).replaceFirst("^0+(?!$)","");
                if(ax.length()!=by.length())return Integer.compare(ax.length(),by.length());int cmp=ax.compareTo(by);if(cmp!=0)return cmp;i=i2;j=j2;
            }else{if(x!=y)return Character.compare(x,y);i++;j++;}
        }return Integer.compare(a.length()-i,b.length()-j);
    }
    private void parseCbz(File source,File root,JSONObject item)throws Exception {
        String id=item.getString("id");File content=new File(root,"content");unzip(source,content);
        ArrayList<String> images=new ArrayList<>();collectImages(content,content,images);images.sort(MainActivity::naturalCompare);
        JSONArray list=new JSONArray();for(String rel:images)list.put(bookURL(id,rel));
        item.put("pages",list).put("pageCount",Math.max(1,images.size()));
        if(!images.isEmpty())item.put("cover",bookURL(id,images.get(0)));
    }
    private static void collectImages(File root,File dir,List<String> out){File[] files=dir.listFiles();if(files==null)return;for(File file:files){if(file.isDirectory())collectImages(root,file,out);else if(file.getName().toLowerCase(Locale.ROOT).matches(".*\\.(png|jpg|jpeg|gif|webp)$")){out.add(root.toURI().relativize(file.toURI()).getPath());}}}
    private String renderPdf(String id,int page,int width){
        String safe=safeId(id);File root=new File(booksRoot,safe);File pdf=new File(root,"source");if(!pdf.isFile())return "";
        int w=Math.max(200,Math.min(width,1800));File folder=new File(root,"pdfpages");folder.mkdirs();
        File output=new File(folder,"page_"+page+"_"+w+".png");
        if(!output.isFile()){if(renderPdfBitmap(pdf,output,page,w)==null)return "";}
        return "files/books/"+safe+"/pdfpages/"+output.getName();
    }
    private static String renderPdfBitmap(File src,File out,int index,int requestedWidth){
        try(ParcelFileDescriptor desc=ParcelFileDescriptor.open(src,ParcelFileDescriptor.MODE_READ_ONLY);PdfRenderer renderer=new PdfRenderer(desc)){
            if(index<0||index>=renderer.getPageCount())return null;
            try(PdfRenderer.Page page=renderer.openPage(index)){
                int width=Math.max(100,requestedWidth);int height=Math.max(100,Math.round(width*page.getHeight()/(float)page.getWidth()));
                if(height>3500){width=Math.round(width*3500f/height);height=3500;}
                Bitmap bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);bitmap.eraseColor(Color.WHITE);
                page.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                try(FileOutputStream stream=new FileOutputStream(out)){bitmap.compress(Bitmap.CompressFormat.PNG,90,stream);}
                bitmap.recycle();return out.getAbsolutePath();
            }
        }catch(Exception e){Log.e(TAG,"PDF render failed",e);return null;}
    }
    @Override public void onBackPressed(){web.evaluateJavascript("window.__androidBack ? window.__androidBack() : false",result->{if("false".equals(result))MainActivity.super.onBackPressed();});}
    @Override public boolean dispatchKeyEvent(KeyEvent event){
        if(volumeKeysEnabled && readerIsOpen &&
             (event.getKeyCode()==KeyEvent.KEYCODE_VOLUME_DOWN||event.getKeyCode()==KeyEvent.KEYCODE_VOLUME_UP)){
            if(event.getAction()==KeyEvent.ACTION_DOWN && event.getRepeatCount()==0){
                int dir=event.getKeyCode()==KeyEvent.KEYCODE_VOLUME_DOWN?1:-1;
                runOnUiThread(()->web.evaluateJavascript("turnPage("+dir+")",null));
            }
            return true;
        }
        return super.dispatchKeyEvent(event);
    }
    @Override protected void onDestroy(){if(web!=null){web.destroy();web=null;}super.onDestroy();}
}
